# Change Log

## [2.0.1] 27.03.2020
### Broken links fixing
- Solve the backlinks errors
- Small change for documentation

## [2.0.0] 22.05.2018
### Bootstrap 4.1.1 integration & Bug Fixing
- Small changes for components
- ChartJS plugin integration
- Gulp task integration to open the project in browser
- Added License for Nucleo Icons
- Small changes on design of Cards

## [1.0.2] 08.03.2017
 - added documentation files

## [1.0.1] 30.09.2016
### Bugfixing, Improvements
- New Page [current version]
- added Upgrade to PRO page for those who want to upsell inside the dashboard
- switched to MIT license

## [1.0.0] 29.03.2016
### Original Release
